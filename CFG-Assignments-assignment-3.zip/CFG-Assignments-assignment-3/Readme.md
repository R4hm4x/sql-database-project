# My CFG Assignments
This is where I will keep all of my assignments that I will wok on throughout the CFG degree

## A bit About me 
Hi I'm **Rahma** and I'm currently *learning how to code* through the CFG course

## Previous Projects
- built a simple website
- created a roll the dice game
- practice using HTML and CSS

## My Goals
1. Get more familiar with Github
2. Improve my coding skills
3. Add projects to my Github
4. Build on my previous knowledge of HTML,CSS and Python.

## Links
[My Github](https://github.com/R4hm4x/CFG-Assignments.git)

## Git Demonstration

### 1. Checking Status
### [git status]


This command helps you see which changes are staged for commit, which are not, and any untracked files.  
In this case, we ran it to check that `status.png` was ready to be committed.

![Git Status Screenshot](screenshots/status.png)

### 2.3. Adding files to a branch and commiting
### [Git add]
### [Git commit]

These commands do the following:

Stages the file so Git knows to include it in the next commit.
Files that are not added will not be saved in the repository yet.
You can add multiple files at once, e.g., git add  to add everything.

Here is the screenshot of me using both
![Git Add Screenshot](screenshots/git-add.png)

### Git push & pull

git pull is how you update your local repository with changes from GitHub (the remote repository).
Use git push after committing changes locally to make them appear on GitHub.

Here is the screenshot of me using both:
![Git push Screenshot](screenshots/git-add.png)

### .gitignore File

 I created a .gitignore file tells Git which files or folders **not to track**.  
This keeps temporary files, logs, and other unnecessary files out of the repository.

## requirements.txt
requirements.txt is a list of all the Python packages your project depends on.
It allows anyone to install the exact same packages you used in your project.
This makes your project reproducible, meaning it will work the same way on any computer.









